#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
if which python3 >/dev/null 2>&1; then
  python3 "$DIR/run_with_python.py"
else
  open "$DIR/QuickCard-Standalone.html"
fi
