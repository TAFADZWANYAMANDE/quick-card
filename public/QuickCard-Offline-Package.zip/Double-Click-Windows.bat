@echo off
echo ===================================================
echo Starting QuickCard Offline...
echo Opening QuickCard in your browser
echo ===================================================
if exist "%~dp0run_with_python.py" (
  python "%~dp0run_with_python.py"
  if errorlevel 1 py "%~dp0run_with_python.py"
  if errorlevel 1 start "" "%~dp0QuickCard-Standalone.html"
) else (
  start "" "%~dp0QuickCard-Standalone.html"
)
exit
